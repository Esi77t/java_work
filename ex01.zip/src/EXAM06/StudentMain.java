package EXAM06;

public class StudentMain {
	public static void main(String[] args) {
		Student std = new Student();
		
		std.Std("홍길동");
		std.StdAge(30);
		std.StdNum(123);
		
		std.StudentInfo();
	}
}
