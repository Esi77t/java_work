package EXAM09;

public class SumofDigits {
	public int sumOfDigits(int num) {
		
	}
}
